﻿using System;
using System.IO;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            using (Process myProcess = new Process())
            {
                //myProcess.StartInfo.FileName = @".\FACE_CHECK.exe";
                //myProcess.StartInfo.Arguments = "/c CLASSWEIGHT/W01.DAT";

                //myProcess.StartInfo.UseShellExecute = false;
                //myProcess.StartInfo.RedirectStandardInput = true;
                //myProcess.StartInfo.RedirectStandardOutput = true;

                //myProcess.Start();

                ProcessStartInfo cmd = new ProcessStartInfo();
                //Process myProcess = new Process();
                cmd.FileName = @".\FACE_CHECK.exe";
                cmd.WindowStyle = ProcessWindowStyle.Hidden;             // cmd창이 숨겨지도록 하기
                cmd.CreateNoWindow = true;                               // cmd창을 띄우지 안도록 하기

                cmd.UseShellExecute = false;
                cmd.RedirectStandardOutput = true;        // cmd창에서 데이터를 가져오기
                cmd.RedirectStandardInput = true;          // cmd창으로 데이터 보내기
                cmd.RedirectStandardError = true;          // cmd창에서 오류 내용 가져오기

                myProcess.EnableRaisingEvents = false;
                myProcess.StartInfo = cmd;
                if (myProcess.Start() == false)
                    Console.WriteLine("Process excute failed!!");
                //myProcess.StandardInput.Write(@"명령어를 넣으면 된다" + Environment.NewLine);


                StreamWriter myStreamWriter = myProcess.StandardInput;
                StreamReader reader = myProcess.StandardOutput;


                // Prompt the user for input text lines to sort.
                // Write each line to the StandardInput stream of
                // the sort command.

                int numLines = 0;

                //Console.WriteLine("Enter a line of text (or press the Enter key to stop):");

                foreach (string readText in System.IO.File.ReadLines(@"LABEL.TXT"))
                {
                    numLines++;
                    myStreamWriter.WriteLine(readText);
                    string output = reader.ReadLine();
                    Console.WriteLine(output);
                }

                // Write a report header to the console.
                if (numLines > 0)
                {
                    Console.WriteLine($" {numLines} sorted text line(s) ");
                    Console.WriteLine("------------------------");
                }
                else
                {
                    Console.WriteLine(" No input was sorted");
                }

                // End the input stream to the sort command.
                // When the stream closes, the sort command
                // writes the sorted text lines to the
                // console.
                myStreamWriter.Close();

                // Wait for the sort process to write the sorted text lines.
                myProcess.WaitForExit();
            }
        }
    }
}
